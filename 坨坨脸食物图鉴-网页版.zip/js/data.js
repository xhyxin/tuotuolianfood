window.APP_DATA = {
  "version": "2.6",
  "updatedAt": "2026-09-25",
  "attitude": {
    "like": "assets/ui/like.png",
    "hate": "assets/ui/hate.png",
    "love": "assets/ui/love.png"
  },
  "characters": [
    {
      "id": "Uros",
      "name": "乌洛斯",
      "en": "Uros",
      "group": "韩服3星",
      "aliases": [
        "Uros"
      ],
      "img": "assets/chars/Uros.png",
      "fav": {
        "love": [
          "F66"
        ],
        "like": [
          "F8",
          "F5",
          "F76",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F2",
          "F14",
          "F80"
        ]
      },
      "source": "wiki",
      "personality": "resonance"
    },
    {
      "id": "Ran",
      "name": "兰",
      "en": "Ran",
      "group": "韩服3星",
      "aliases": [
        "Ran"
      ],
      "img": "assets/chars/Ran.png",
      "fav": {
        "love": [
          "F61"
        ],
        "like": [
          "F11",
          "F18",
          "F74",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F1",
          "F20",
          "F68",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Vivi",
      "name": "薇薇",
      "en": "Vivi",
      "group": "韩服3星",
      "aliases": [
        "Vivi"
      ],
      "img": "assets/chars/Vivi.png",
      "fav": {
        "love": [
          "F9",
          "F84"
        ],
        "like": [
          "F18",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F74",
          "F90"
        ],
        "hate": [
          "F5",
          "F20",
          "F76",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "ErpinRolyale",
      "name": "埃尔芬（王道）",
      "en": "ErpinRolyale",
      "group": "韩服3星",
      "aliases": [
        "ErpinRolyale"
      ],
      "img": "assets/chars/Erpin2.5.png",
      "fav": {
        "love": [
          "F38",
          "F68"
        ],
        "like": [
          "F1",
          "F2",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F27",
          "F25",
          "F81"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Sherum",
      "name": "莎伦",
      "en": "Sherum",
      "group": "韩服3星",
      "aliases": [
        "Sherum"
      ],
      "img": "assets/chars/Sherum.png",
      "fav": {
        "love": [],
        "like": [
          "F29",
          "F9",
          "F84",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F4",
          "F27",
          "F73"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Haley",
      "name": "海莉",
      "en": "Haley",
      "group": "韩服3星",
      "aliases": [
        "Haley"
      ],
      "img": "assets/chars/Haley.png",
      "fav": {
        "love": [
          "F67"
        ],
        "like": [
          "F30",
          "F10",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F79",
          "F90"
        ],
        "hate": [
          "F9",
          "F27",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Naia",
      "name": "奈亚",
      "en": "Naia",
      "group": "韩服3星",
      "aliases": [
        "Naia"
      ],
      "img": "assets/chars/Naia.png",
      "fav": {
        "love": [
          "F56",
          "F87"
        ],
        "like": [
          "F16",
          "F24",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F83",
          "F90"
        ],
        "hate": [
          "F12",
          "F11",
          "F69"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Kyarot",
      "name": "卡萝特",
      "en": "Kyarot",
      "group": "韩服3星",
      "aliases": [
        "Kyarot"
      ],
      "img": "assets/chars/Kyarot.png",
      "fav": {
        "love": [
          "F50",
          "F80"
        ],
        "like": [
          "F15",
          "F14",
          "F70",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F9",
          "F76",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Daya",
      "name": "达雅",
      "en": "Daya",
      "group": "韩服3星",
      "aliases": [
        "Daya"
      ],
      "img": "assets/chars/Daya.png",
      "fav": {
        "love": [
          "F64"
        ],
        "like": [
          "F21",
          "F10",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F79",
          "F90"
        ],
        "hate": [
          "F23",
          "F5",
          "F71",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Erpin",
      "name": "埃尔芬",
      "en": "Erpin",
      "group": "韩服3星",
      "aliases": [
        "Erpin",
        "猪芬"
      ],
      "img": "assets/chars/Erpin.png",
      "fav": {
        "love": [
          "F38",
          "F68"
        ],
        "like": [
          "F1",
          "F2",
          "F36",
          "F31",
          "F90",
          "F34",
          "F35",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F27",
          "F25",
          "F81"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Opal",
      "name": "欧珀",
      "en": "Opal",
      "group": "韩服3星",
      "aliases": [
        "Opal"
      ],
      "img": "assets/chars/Opal.png",
      "fav": {
        "love": [
          "F64"
        ],
        "like": [
          "F24",
          "F21",
          "F83",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F25",
          "F76",
          "F81"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Laika",
      "name": "莱卡",
      "en": "Laika",
      "group": "韩服3星",
      "aliases": [
        "Laika"
      ],
      "img": "assets/chars/Laika.png",
      "fav": {
        "love": [
          "F41",
          "F69"
        ],
        "like": [
          "F13",
          "F12",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F20",
          "F18",
          "F74",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Mayo(Cool)",
      "name": "玛约(超帅)",
      "en": "Mayo(Cool)",
      "group": "韩服3星",
      "aliases": [
        "Mayo(Cool)"
      ],
      "img": "assets/chars/MayoCool.png",
      "fav": {
        "love": [
          "F61"
        ],
        "like": [
          "F30",
          "F11",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F23",
          "F6",
          "F71",
          "F78"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "kathy",
      "name": "凯茜",
      "en": "kathy",
      "group": "韩服3星",
      "aliases": [
        "kathy"
      ],
      "img": "assets/chars/Kathy.png",
      "fav": {
        "love": [
          "F41",
          "F69"
        ],
        "like": [
          "F12",
          "F10",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F19",
          "F20",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Mute",
      "name": "穆特",
      "en": "Mute",
      "group": "韩服3星",
      "aliases": [
        "Mute"
      ],
      "img": "assets/chars/Mute.png",
      "fav": {
        "love": [
          "F61"
        ],
        "like": [
          "F11",
          "F12",
          "F69",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F21",
          "F15",
          "F70"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Ayla",
      "name": "阿依拉",
      "en": "Ayla",
      "group": "韩服3星",
      "aliases": [
        "Ayla"
      ],
      "img": "assets/chars/Ayla.png",
      "fav": {
        "love": [
          "F56",
          "F87"
        ],
        "like": [
          "F10",
          "F16",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F12",
          "F22",
          "F69",
          "F85"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Delia",
      "name": "黛莉娅",
      "en": "Delia",
      "group": "韩服3星",
      "aliases": [
        "Delia"
      ],
      "img": "assets/chars/Delia.png",
      "fav": {
        "love": [
          "F65"
        ],
        "like": [
          "F27",
          "F26",
          "F86",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F10",
          "F18",
          "F74",
          "F79"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "伊德（康复）",
      "name": "伊德（康复）",
      "en": "",
      "group": "韩服3星",
      "aliases": [],
      "img": "assets/chars/EdWakeUp.png",
      "fav": {
        "love": [
          "F61"
        ],
        "like": [
          "F11",
          "F28",
          "F72",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F18",
          "F74",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Sparrot",
      "name": "斯帕洛特",
      "en": "Sparrot",
      "group": "韩服3星",
      "aliases": [
        "Sparrot"
      ],
      "img": "assets/chars/Sparrot.png",
      "fav": {
        "love": [
          "F61"
        ],
        "like": [
          "F11",
          "F3",
          "F82",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F25",
          "F12",
          "F81"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Diana(Yester)",
      "name": "黛安娜（往昔）",
      "en": "Diana(Yester)",
      "group": "韩服3星",
      "aliases": [
        "Diana(Yester)"
      ],
      "img": "assets/chars/DianaYester.png",
      "fav": {
        "love": [
          "F66"
        ],
        "like": [
          "F8",
          "F6",
          "F78",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F4",
          "F13",
          "F73"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Ed",
      "name": "伊德",
      "en": "Ed",
      "group": "韩服3星",
      "aliases": [
        "Ed"
      ],
      "img": "assets/chars/Ed.png",
      "fav": {
        "love": [
          "F61"
        ],
        "like": [
          "F28",
          "F11",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F72",
          "F90"
        ],
        "hate": [
          "F9",
          "F18",
          "F74",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Aya",
      "name": "绫",
      "en": "Aya",
      "group": "韩服3星",
      "aliases": [
        "Aya"
      ],
      "img": "assets/chars/Aya.png",
      "fav": {
        "love": [
          "F65"
        ],
        "like": [
          "F2",
          "F27",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F30",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Barong",
      "name": "巴隆",
      "en": "Barong",
      "group": "韩服3星",
      "aliases": [
        "Barong"
      ],
      "img": "assets/chars/Barong.png",
      "fav": {
        "love": [
          "F64"
        ],
        "like": [
          "F18",
          "F21",
          "F74",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F14",
          "F12",
          "F69",
          "F80"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Velvet",
      "name": "薇尔薇特",
      "en": "Velvet",
      "group": "韩服3星",
      "aliases": [
        "Velvet"
      ],
      "img": "assets/chars/Velvet.png",
      "fav": {
        "love": [
          "F50",
          "F80"
        ],
        "like": [
          "F25",
          "F14",
          "F81",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F29",
          "F1",
          "F68",
          "F75"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "KommySwim",
      "name": "柯米(泳装)",
      "en": "KommySwim",
      "group": "韩服3星",
      "aliases": [
        "KommySwim"
      ],
      "img": "assets/chars/KommySwim.png",
      "fav": {
        "love": [
          "F40",
          "F76"
        ],
        "like": [
          "F5",
          "F4",
          "F31",
          "F33",
          "F35",
          "F32",
          "F73",
          "F90",
          "F34",
          "F36",
          "F37"
        ],
        "hate": [
          "F28",
          "F8",
          "F72"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Fricle",
      "name": "芙莉克",
      "en": "Fricle",
      "group": "韩服3星",
      "aliases": [
        "Fricle"
      ],
      "img": "assets/chars/Fricle.png",
      "fav": {
        "love": [
          "F59"
        ],
        "like": [
          "F6",
          "F7",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F90",
          "F37"
        ],
        "hate": [
          "F28",
          "F4"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Elena",
      "name": "埃蕾娜",
      "en": "Elena",
      "group": "韩服3星",
      "aliases": [
        "Elena"
      ],
      "img": "assets/chars/Elena.png",
      "fav": {
        "love": [
          "F55",
          "F84"
        ],
        "like": [
          "F12",
          "F9",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F69",
          "F90"
        ],
        "hate": [
          "F11",
          "F26",
          "F86"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Jade",
      "name": "婕德",
      "en": "Jade",
      "group": "韩服3星",
      "aliases": [
        "Jade"
      ],
      "img": "assets/chars/Jade.png",
      "fav": {
        "love": [
          "F65"
        ],
        "like": [
          "F23",
          "F27",
          "F71",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F7",
          "F8",
          "F89"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Picora",
      "name": "皮可拉",
      "en": "Picora",
      "group": "韩服3星",
      "aliases": [
        "Picora"
      ],
      "img": "assets/chars/Picora.png",
      "fav": {
        "love": [
          "F52",
          "F83"
        ],
        "like": [
          "F24",
          "F9",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F84",
          "F90"
        ],
        "hate": [
          "F1",
          "F2",
          "F68"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Amelia",
      "name": "艾蜜莉雅",
      "en": "Amelia",
      "group": "韩服3星",
      "aliases": [
        "Amelia"
      ],
      "img": "assets/chars/Amelia.png",
      "fav": {
        "love": [
          "F41",
          "F69"
        ],
        "like": [
          "F12",
          "F2",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F90"
        ],
        "hate": [
          "F25",
          "F30",
          "F81"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Meluna",
      "name": "梅芦娜",
      "en": "Meluna",
      "group": "韩服3星",
      "aliases": [
        "Meluna"
      ],
      "img": "assets/chars/Meluna.png",
      "fav": {
        "love": [
          "F62"
        ],
        "like": [
          "F13",
          "F14",
          "F80",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F28",
          "F29",
          "F72",
          "F75"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Sylla",
      "name": "希拉",
      "en": "Sylla",
      "group": "韩服3星",
      "aliases": [
        "Sylla"
      ],
      "img": "assets/chars/Sylla.png",
      "fav": {
        "love": [
          "F51",
          "F77"
        ],
        "like": [
          "F20",
          "F15",
          "F70",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F19",
          "F12",
          "F69"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Guin",
      "name": "格温",
      "en": "Guin",
      "group": "韩服3星",
      "aliases": [
        "Guin"
      ],
      "img": "assets/chars/Guin.png",
      "fav": {
        "love": [
          "F54",
          "F86"
        ],
        "like": [
          "F27",
          "F26",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F71",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "eisia",
      "name": "艾西亚",
      "en": "eisia",
      "group": "韩服3星",
      "aliases": [
        "eisia"
      ],
      "img": "assets/chars/Eisia.png",
      "fav": {
        "love": [
          "F60"
        ],
        "like": [
          "F2",
          "F27",
          "F36",
          "F90",
          "F34",
          "F35",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F63",
          "F14",
          "F80"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "ricotta",
      "name": "里科塔",
      "en": "ricotta",
      "group": "韩服3星",
      "aliases": [
        "ricotta"
      ],
      "img": "assets/chars/Ricota.png",
      "fav": {
        "love": [
          "F54",
          "F86"
        ],
        "like": [
          "F26",
          "F14",
          "F32",
          "F31",
          "F33",
          "F80",
          "F90",
          "F34",
          "F35",
          "F36",
          "F37"
        ],
        "hate": [
          "F5",
          "F12",
          "F69",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Scizor",
      "name": "凯撒",
      "en": "Scizor",
      "group": "韩服3星",
      "aliases": [
        "Scizor"
      ],
      "img": "assets/chars/Scizor.png",
      "fav": {
        "love": [
          "F60"
        ],
        "like": [
          "F2",
          "F20",
          "F77",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "X133373",
          "F12",
          "F69"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "BeniBeni",
      "name": "班尼（班尼）",
      "en": "BeniBeni",
      "group": "韩服3星",
      "aliases": [
        "BeniBeni"
      ],
      "img": "assets/chars/BeniBeni.png",
      "fav": {
        "love": [
          "F42",
          "F70"
        ],
        "like": [
          "F15",
          "F26",
          "F86",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F23",
          "F71",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "inkle",
      "name": "尹可",
      "en": "inkle",
      "group": "韩服3星",
      "aliases": [
        "inkle"
      ],
      "img": "assets/chars/Inkle.png",
      "fav": {
        "love": [
          "F45",
          "F72"
        ],
        "like": [
          "F28",
          "F10",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F21",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Aragnia",
      "name": "阿拉戈尼娅",
      "en": "Aragnia",
      "group": "韩服3星",
      "aliases": [
        "Aragnia"
      ],
      "img": "assets/chars/Aragnia.png",
      "fav": {
        "love": [
          "F58",
          "F85"
        ],
        "like": [
          "F22",
          "F7",
          "F89",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F18",
          "F74",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Nicole",
      "name": "妮可",
      "en": "Nicole",
      "group": "韩服3星",
      "aliases": [
        "Nicole"
      ],
      "img": "assets/chars/nike.png",
      "fav": {
        "love": [
          "F39",
          "F73"
        ],
        "like": [
          "F3",
          "F4",
          "F82",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F16",
          "F12",
          "F69",
          "F87"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Silvia",
      "name": "西尔维娅",
      "en": "Silvia",
      "group": "韩服3星",
      "aliases": [
        "Silvia"
      ],
      "img": "assets/chars/Silvia_Happy_1.png",
      "fav": {
        "love": [
          "F49",
          "F79"
        ],
        "like": [
          "F10",
          "F21",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F8",
          "F5",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "TigHero",
      "name": "提格（英雄）",
      "en": "Tig",
      "group": "韩服3星",
      "aliases": [
        "Tig"
      ],
      "img": "assets/chars/TigHero.png",
      "fav": {
        "love": [
          "F66"
        ],
        "like": [
          "F8",
          "F11",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F18",
          "F74",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Renewa",
      "name": "莉纽阿",
      "en": "Renewa",
      "group": "韩服3星",
      "aliases": [
        "Renewa"
      ],
      "img": "assets/chars/Renewa.png",
      "fav": {
        "love": [
          "F49",
          "F79"
        ],
        "like": [
          "F10",
          "F12",
          "F36",
          "F34",
          "F35",
          "F31",
          "F33",
          "F37",
          "F32",
          "F69",
          "F75",
          "F90"
        ],
        "hate": [
          "F4",
          "F11",
          "F73"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Chloe",
      "name": "克萝伊",
      "en": "Chloe",
      "group": "韩服3星",
      "aliases": [
        "Chloe"
      ],
      "img": "assets/chars/Chloe.png",
      "fav": {
        "love": [
          "F48",
          "F78"
        ],
        "like": [
          "F10",
          "F6",
          "F34",
          "F32",
          "F33",
          "F31",
          "F35",
          "F36",
          "F37",
          "F79",
          "F90"
        ],
        "hate": [
          "F20",
          "F23",
          "F71",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Leets",
      "name": "丽兹",
      "en": "Leets",
      "group": "韩服3星",
      "aliases": [
        "Leets"
      ],
      "img": "assets/chars/Leets.png",
      "fav": {
        "love": [
          "F44",
          "F71"
        ],
        "like": [
          "F23",
          "F20",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F77",
          "F90",
          "F37"
        ],
        "hate": [
          "F21",
          "F15",
          "F70"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Shady",
      "name": "夏迪",
      "en": "Shady",
      "group": "韩服3星",
      "aliases": [
        "Shady"
      ],
      "img": "assets/chars/Shady.png",
      "fav": {
        "love": [
          "F63"
        ],
        "like": [
          "F22",
          "F19",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F85",
          "F90",
          "F37"
        ],
        "hate": [
          "F5",
          "F17",
          "F76",
          "F88"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Ner",
      "name": "尼尔",
      "en": "Ner",
      "group": "韩服3星",
      "aliases": [
        "Ner"
      ],
      "img": "assets/chars/Ner.png",
      "fav": {
        "love": [
          "F46",
          "F75"
        ],
        "like": [
          "F29",
          "F13",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F4",
          "F16",
          "F73",
          "F87"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Alice",
      "name": "爱丽丝",
      "en": "Alice",
      "group": "韩服3星",
      "aliases": [
        "Alice"
      ],
      "img": "assets/chars/Alice.png",
      "fav": {
        "love": [
          "F49",
          "F79"
        ],
        "like": [
          "F10",
          "F19",
          "F31",
          "F33",
          "F35",
          "F36",
          "F32",
          "F34",
          "F37",
          "F90"
        ],
        "hate": [
          "F9",
          "F16",
          "F84",
          "F87"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Diana",
      "name": "黛安娜",
      "en": "Diana",
      "group": "韩服3星",
      "aliases": [
        "Diana"
      ],
      "img": "assets/chars/Diana.png",
      "fav": {
        "love": [
          "F66"
        ],
        "like": [
          "F6",
          "F8",
          "F31",
          "F32",
          "F78",
          "F90",
          "F34",
          "F35",
          "F36",
          "F33",
          "F37"
        ],
        "hate": [
          "F13",
          "F4",
          "F73"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Sist",
      "name": "茜斯特",
      "en": "Sist",
      "group": "韩服3星",
      "aliases": [
        "Sist"
      ],
      "img": "assets/chars/Sist.png",
      "fav": {
        "love": [
          "F62"
        ],
        "like": [
          "F9",
          "F13",
          "F84",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F18",
          "F27",
          "F74"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Belita",
      "name": "贝丽塔",
      "en": "Belita",
      "group": "韩服3星",
      "aliases": [
        "Belita"
      ],
      "img": "assets/chars/Belita.png",
      "fav": {
        "love": [
          "F38",
          "F68"
        ],
        "like": [
          "F1",
          "F2",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F20",
          "F27",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Rollett",
      "name": "罗莱特",
      "en": "Rollett",
      "group": "韩服3星",
      "aliases": [
        "Rollett"
      ],
      "img": "assets/chars/Rollett.png",
      "fav": {
        "love": [
          "F47",
          "F82"
        ],
        "like": [
          "F13",
          "F3",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F11",
          "F24",
          "F83"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Pira",
      "name": "皮拉",
      "en": "Pira",
      "group": "韩服3星",
      "aliases": [
        "Pira"
      ],
      "img": "assets/chars/Pira.png",
      "fav": {
        "love": [],
        "like": [
          "F23",
          "F11",
          "F71",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F21",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Polan",
      "name": "破朗",
      "en": "Polan",
      "group": "韩服3星",
      "aliases": [
        "Polan"
      ],
      "img": "assets/chars/Polan.png",
      "fav": {
        "love": [
          "F38",
          "F68"
        ],
        "like": [
          "F1",
          "F7",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F11",
          "F3",
          "F82"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "RimChaos",
      "name": "混沌琳",
      "en": "RimChaos",
      "group": "韩服3星",
      "aliases": [
        "RimChaos"
      ],
      "img": "assets/chars/RimChaos.png",
      "fav": {
        "love": [
          "F57",
          "F88"
        ],
        "like": [
          "F11",
          "F17",
          "F35",
          "F90",
          "F34",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F3",
          "F29",
          "F75",
          "F82"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Neti",
      "name": "内蒂",
      "en": "Neti",
      "group": "韩服3星",
      "aliases": [
        "Neti"
      ],
      "img": "assets/chars/Neti.png",
      "fav": {
        "love": [
          "F44",
          "F71"
        ],
        "like": [
          "F21",
          "F23",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F20",
          "F76",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Arnet",
      "name": "阿妮特",
      "en": "Arnet",
      "group": "韩服3星",
      "aliases": [
        "Arnet"
      ],
      "img": "assets/chars/Arnet.png",
      "fav": {
        "love": [
          "F4"
        ],
        "like": [
          "F21",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F76",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Heidi",
      "name": "海蒂",
      "en": "Heidi",
      "group": "韩服3星",
      "aliases": [
        "Heidi"
      ],
      "img": "assets/chars/Heidi.png",
      "fav": {
        "love": [
          "F64"
        ],
        "like": [
          "F21",
          "F6",
          "F78",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F12",
          "F7",
          "F69"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "DayaPureShine",
      "name": "达雅（纯真闪耀）",
      "en": "DayaPureShine",
      "group": "韩服3星",
      "aliases": [
        "DayaPureShine"
      ],
      "img": "assets/chars/DayaPureShine.png",
      "fav": {
        "love": [
          "F64"
        ],
        "like": [
          "F21",
          "F10",
          "F79",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F23",
          "F5",
          "F71",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "HaleySane",
      "name": "海莉（清醒）",
      "en": "HaleySane",
      "group": "韩服3星",
      "aliases": [
        "HaleySane"
      ],
      "img": "assets/chars/haleyWakeUp.png",
      "fav": {
        "love": [
          "F67"
        ],
        "like": [
          "F30",
          "F10",
          "F79",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F27",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "skea",
      "name": "斯琪娅",
      "en": "skea",
      "group": "韩服3星",
      "aliases": [
        "skea"
      ],
      "img": "assets/chars/spy.png",
      "fav": {
        "love": [
          "F52",
          "F83"
        ],
        "like": [
          "F24",
          "F11",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F6",
          "F25",
          "F78",
          "F81"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Ronnie",
      "name": "罗尼",
      "en": "Ronnie",
      "group": "韩服3星",
      "aliases": [
        "Ronnie"
      ],
      "img": "assets/chars/Ronnie.png",
      "fav": {
        "love": [
          "F52"
        ],
        "like": [
          "F24",
          "F2",
          "F83",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F20",
          "F12",
          "F69"
        ]
      },
      "source": "manual",
      "personality": "frenzy"
    },
    {
      "id": "Vela",
      "name": "贝拉",
      "en": "Vela",
      "group": "韩服3星",
      "aliases": [
        "Vela"
      ],
      "img": "assets/chars/Vela.png",
      "fav": {
        "love": [
          "F63"
        ],
        "like": [
          "F17",
          "F19",
          "F88",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F6",
          "F30"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Epica",
      "name": "埃皮卡",
      "en": "Epica",
      "group": "韩服3星",
      "aliases": [
        "Epica"
      ],
      "img": "assets/chars/Epica.png",
      "fav": {
        "love": [
          "F4",
          "F73"
        ],
        "like": [
          "F8",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F6",
          "F76",
          "F78"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Ui",
      "name": "雨伊",
      "en": "Ui",
      "group": "韩服3星",
      "aliases": [
        "Ui"
      ],
      "img": "assets/chars/Ui.png",
      "fav": {
        "love": [
          "F56",
          "F87"
        ],
        "like": [
          "F32",
          "F16",
          "F31",
          "F8",
          "F90",
          "F34",
          "F35",
          "F36",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F17",
          "F84",
          "F88"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "NerRage",
      "name": "涅尔（义愤）",
      "en": "NerRage",
      "group": "韩服3星",
      "aliases": [
        "NerRage"
      ],
      "img": "assets/chars/Ner2.5.png",
      "fav": {
        "love": [
          "F46",
          "F75"
        ],
        "like": [
          "F29",
          "F13",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F4",
          "F16",
          "F73",
          "F87"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Tig",
      "name": "提格",
      "en": "Tig",
      "group": "韩服3星",
      "aliases": [
        "Tig"
      ],
      "img": "assets/chars/Tig.png",
      "fav": {
        "love": [
          "F66"
        ],
        "like": [
          "F8",
          "F11",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F90"
        ],
        "hate": [
          "F5",
          "F18",
          "F74",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Selline",
      "name": "赛琳娜",
      "en": "Selline",
      "group": "韩服3星",
      "aliases": [
        "Selline"
      ],
      "img": "assets/chars/Selline.png",
      "fav": {
        "love": [
          "F63"
        ],
        "like": [
          "F19",
          "F11",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F10",
          "F29",
          "F75",
          "F79"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Rude",
      "name": "鲁德",
      "en": "Rude",
      "group": "韩服3星",
      "aliases": [
        "Rude"
      ],
      "img": "assets/chars/Rude.png",
      "fav": {
        "love": [
          "F59",
          "F89"
        ],
        "like": [
          "F12",
          "F7",
          "F69",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F14",
          "F30",
          "F80"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Rufo",
      "name": "卢波",
      "en": "Rufo",
      "group": "韩服3星",
      "aliases": [
        "Rufo"
      ],
      "img": "assets/chars/Rufo.png",
      "fav": {
        "love": [
          "F54",
          "F86"
        ],
        "like": [
          "F32",
          "F26",
          "F13",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F33",
          "F37"
        ],
        "hate": [
          "F15",
          "F17",
          "F70",
          "F88"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Shoupan",
      "name": "舒胖",
      "en": "Shoupan",
      "group": "韩服3星",
      "aliases": [
        "Shoupan"
      ],
      "img": "assets/chars/Shoupan.png",
      "fav": {
        "love": [
          "F41",
          "F69"
        ],
        "like": [
          "F2",
          "F12",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F90",
          "F37"
        ],
        "hate": [
          "F16",
          "F17",
          "F87",
          "F88"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Momo",
      "name": "小桃",
      "en": "Momo",
      "group": "韩服3星",
      "aliases": [
        "Momo"
      ],
      "img": "assets/chars/Momo.png",
      "fav": {
        "love": [
          "F15",
          "F70"
        ],
        "like": [
          "F20",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F77",
          "F90"
        ],
        "hate": [
          "F18",
          "F3",
          "F74",
          "F82"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Butter",
      "name": "黄油",
      "en": "Butter",
      "group": "韩服3星",
      "aliases": [
        "Butter"
      ],
      "img": "assets/chars/Butter.png",
      "fav": {
        "love": [
          "F4",
          "F73"
        ],
        "like": [
          "F5",
          "F32",
          "F31",
          "F76",
          "F90",
          "F34",
          "F35",
          "F36",
          "F33",
          "F37"
        ],
        "hate": [
          "F2",
          "F29",
          "F75"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Canna",
      "name": "康娜",
      "en": "Canna",
      "group": "韩服3星",
      "aliases": [
        "Canna"
      ],
      "img": "assets/chars/Canna.png",
      "fav": {
        "love": [
          "F67"
        ],
        "like": [
          "F8",
          "F32",
          "F31",
          "F30",
          "F90",
          "F34",
          "F35",
          "F36",
          "F33",
          "F37"
        ],
        "hate": [
          "F10",
          "F25",
          "F79",
          "F81"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "SpeakiMaid",
      "name": "斯碧琪（女仆）",
      "en": "Speaki",
      "group": "韩服3星",
      "aliases": [
        "Speaki"
      ],
      "img": "assets/chars/SpeakiMaid.png",
      "fav": {
        "love": [
          "F43",
          "F74"
        ],
        "like": [
          "F22",
          "F18",
          "F85",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F17",
          "F6",
          "F78",
          "F88"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Suro",
      "name": "修罗",
      "en": "Suro",
      "group": "韩服3星",
      "aliases": [
        "Suro"
      ],
      "img": "assets/chars/Suro.png",
      "fav": {
        "love": [
          "F66"
        ],
        "like": [
          "F5",
          "F8",
          "F76",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F2",
          "F14",
          "F80"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Arco",
      "name": "阿尔柯",
      "en": "Arco",
      "group": "韩服3星",
      "aliases": [
        "Arco"
      ],
      "img": "assets/chars/Arco.png",
      "fav": {
        "love": [
          "F61"
        ],
        "like": [
          "F11",
          "F3",
          "F82",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F10",
          "F12",
          "F69",
          "F79"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Makasha",
      "name": "玛卡莎",
      "en": "Makasha",
      "group": "韩服3星",
      "aliases": [
        "Makasha"
      ],
      "img": "assets/chars/Makasha.png",
      "fav": {
        "love": [
          "F59",
          "F89"
        ],
        "like": [
          "F7",
          "F9",
          "F84",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F25",
          "F29",
          "F75",
          "F81"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Miro",
      "name": "米洛",
      "en": "Miro",
      "group": "韩服3星",
      "aliases": [
        "Miro"
      ],
      "img": "assets/chars/Miro.png",
      "fav": {
        "love": [
          "F65"
        ],
        "like": [
          "F27",
          "F70",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F19",
          "F17",
          "F88"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "ShadyTwisted",
      "name": "夏迪（逆转）",
      "en": "ShadyTwisted",
      "group": "韩服3星",
      "aliases": [
        "ShadyTwisted"
      ],
      "img": "assets/chars/ShadyTwisted.png",
      "fav": {
        "love": [
          "F63"
        ],
        "like": [
          "F19",
          "F22",
          "F85",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F17",
          "F76",
          "F88"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "LeviGraduate",
      "name": "莱薇（毕业）",
      "en": "LeviGraduate",
      "group": "韩服3星",
      "aliases": [
        "LeviGraduate"
      ],
      "img": "assets/chars/LeviBiYe.png",
      "fav": {
        "love": [
          "F39",
          "F73"
        ],
        "like": [
          "F4",
          "F28",
          "F72",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F25",
          "F3",
          "F81",
          "F82"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "AshurMagi",
      "name": "艾舒尔（魔道）",
      "en": "AshurMagi",
      "group": "韩服3星",
      "aliases": [
        "AshurMagi"
      ],
      "img": "assets/chars/Ashur3.png",
      "fav": {
        "love": [
          "F45",
          "F72"
        ],
        "like": [
          "F28",
          "F4",
          "F73",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F22",
          "F13",
          "F85"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "yomi",
      "name": "优米",
      "en": "yomi",
      "group": "韩服3星",
      "aliases": [
        "yomi"
      ],
      "img": "assets/chars/Yomi.png",
      "fav": {
        "love": [
          "F57",
          "F88"
        ],
        "like": [
          "F17",
          "F14",
          "F80",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F3",
          "F1",
          "F68",
          "F82"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Joanne",
      "name": "琼安",
      "en": "Joanne",
      "group": "韩服3星",
      "aliases": [
        "Joanne"
      ],
      "img": "assets/chars/Joanne.png",
      "fav": {
        "love": [
          "F59",
          "F89"
        ],
        "like": [
          "F27",
          "F7",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F1",
          "F29",
          "F68",
          "F75"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "xXionx",
      "name": "x锡安x",
      "en": "xXionx",
      "group": "韩服3星",
      "aliases": [
        "xXionx"
      ],
      "img": "assets/chars/xXionx.png",
      "fav": {
        "love": [
          "F60"
        ],
        "like": [
          "F11",
          "F2",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F90"
        ],
        "hate": [
          "F5",
          "F21",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Kommy",
      "name": "柯米",
      "en": "Kommy",
      "group": "韩服3星",
      "aliases": [
        "Kommy"
      ],
      "img": "assets/chars/Kommy.png",
      "fav": {
        "love": [
          "F40",
          "F76"
        ],
        "like": [
          "F4",
          "F5",
          "F32",
          "F73",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F33",
          "F37"
        ],
        "hate": [
          "F28",
          "F8",
          "F72"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Kidian",
      "name": "基迪恩",
      "en": "Kidian",
      "group": "韩服3星",
      "aliases": [
        "Kidian"
      ],
      "img": "assets/chars/Kidian.png",
      "fav": {
        "love": [
          "F48",
          "F78"
        ],
        "like": [
          "F5",
          "F6",
          "F32",
          "F76",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F33",
          "F37"
        ],
        "hate": [
          "F24",
          "F7",
          "F83",
          "F89"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Snorky",
      "name": "斯诺琪",
      "en": "Snorky",
      "group": "韩服3星",
      "aliases": [
        "Snorky"
      ],
      "img": "assets/chars/Snorky.png",
      "fav": {
        "love": [
          "F67"
        ],
        "like": [
          "F30",
          "F7",
          "F89",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F11",
          "F28",
          "F72"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Rim",
      "name": "琳",
      "en": "Rim",
      "group": "韩服3星",
      "aliases": [
        "Rim"
      ],
      "img": "assets/chars/Rim.png",
      "fav": {
        "love": [
          "F57",
          "F88"
        ],
        "like": [
          "F11",
          "F17",
          "F31",
          "F32",
          "F90",
          "F34",
          "F35",
          "F36",
          "F33",
          "F37"
        ],
        "hate": [
          "F3",
          "F29",
          "F75",
          "F82"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Blanchet",
      "name": "布蓝琪",
      "en": "Blanchet",
      "group": "韩服3星",
      "aliases": [
        "Blanchet"
      ],
      "img": "assets/chars/Blanchet.png",
      "fav": {
        "love": [
          "F49",
          "F79"
        ],
        "like": [
          "F21",
          "F10",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F90"
        ],
        "hate": [
          "F20",
          "F12",
          "F69",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Hilde",
      "name": "希尔德",
      "en": "Hilde",
      "group": "韩服3星",
      "aliases": [
        "Hilde"
      ],
      "img": "assets/chars/Hilde.png",
      "fav": {
        "love": [
          "F54",
          "F86"
        ],
        "like": [
          "F26",
          "F12",
          "F69",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F29",
          "F23",
          "F71",
          "F75"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Posher",
      "name": "珀榭",
      "en": "Posher",
      "group": "韩服3星",
      "aliases": [
        "Posher"
      ],
      "img": "assets/chars/Posher.png",
      "fav": {
        "love": [
          "F53",
          "F81"
        ],
        "like": [
          "F12",
          "F25",
          "F32",
          "F69",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F33",
          "F37"
        ],
        "hate": [
          "F26",
          "F17",
          "F86",
          "F88"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Ashur",
      "name": "艾舒尔",
      "en": "Ashur",
      "group": "韩服3星",
      "aliases": [
        "Ashur"
      ],
      "img": "assets/chars/Ashur.png",
      "fav": {
        "love": [
          "F45",
          "F72"
        ],
        "like": [
          "F4",
          "F28",
          "F73",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F22",
          "F13",
          "F85"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Risty",
      "name": "莉斯缇",
      "en": "Risty",
      "group": "韩服3星",
      "aliases": [
        "Risty"
      ],
      "img": "assets/chars/Risty.png",
      "fav": {
        "love": [
          "F58",
          "F85"
        ],
        "like": [
          "F22",
          "F32",
          "F31",
          "F33",
          "F34",
          "F35",
          "F36",
          "F37",
          "F9",
          "F84",
          "F90"
        ],
        "hate": [
          "F13",
          "F7",
          "F86"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Lion",
      "name": "里昂",
      "en": "Lion",
      "group": "韩服3星",
      "aliases": [
        "Lion"
      ],
      "img": "assets/chars/Lion.png",
      "fav": {
        "love": [
          "F66"
        ],
        "like": [
          "F26",
          "F8",
          "F86",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F11",
          "F12",
          "F69"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Shasha",
      "name": "夏夏",
      "en": "Shasha",
      "group": "韩服3星",
      "aliases": [
        "Shasha"
      ],
      "img": "assets/chars/Shasha.png",
      "fav": {
        "love": [
          "F48",
          "F78"
        ],
        "like": [
          "F1",
          "F6",
          "F68",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F16",
          "F18",
          "F74",
          "F87"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Orr",
      "name": "欧尔",
      "en": "Orr",
      "group": "韩服3星",
      "aliases": [
        "Orr"
      ],
      "img": "assets/chars/Orr.png",
      "fav": {
        "love": [
          "F55",
          "F84"
        ],
        "like": [
          "F9",
          "F20",
          "F77",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F2",
          "F3",
          "F82"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "RohneMayor",
      "name": "洛涅（市长）",
      "en": "Rohne",
      "group": "韩服3星",
      "aliases": [
        "Rohne"
      ],
      "img": "assets/chars/RohneMayor.png",
      "fav": {
        "love": [
          "F52",
          "F83"
        ],
        "like": [
          "F24",
          "F2",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F20",
          "F12",
          "F69",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Asana",
      "name": "阿萨娜",
      "en": "Asana",
      "group": "韩服3星",
      "aliases": [
        "Asana"
      ],
      "img": "assets/chars/Asana.png",
      "fav": {
        "love": [
          "F50",
          "F80"
        ],
        "like": [
          "F14",
          "F25",
          "F81",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F1",
          "F29",
          "F68",
          "F75"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "AmeliaR41",
      "name": "艾蜜莉雅（R41）",
      "en": "AmeliaR41",
      "group": "韩服3星",
      "aliases": [
        "AmeliaR41"
      ],
      "img": "assets/chars/AmeliaR41.png",
      "fav": {
        "love": [
          "F67"
        ],
        "like": [
          "F30",
          "F2",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F25",
          "F12",
          "F69",
          "F81"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Kishya",
      "name": "绮莎",
      "en": "Kishya",
      "group": "韩服3星",
      "aliases": [
        "Kishya"
      ],
      "img": "assets/chars/qisha.png",
      "fav": {
        "love": [
          "F58",
          "F85"
        ],
        "like": [
          "F24",
          "F22",
          "F83",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F25",
          "F7",
          "F81",
          "F89"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Aurora",
      "name": "欧若拉",
      "en": "Aurora",
      "group": "韩服3星",
      "aliases": [
        "Aurora"
      ],
      "img": "assets/chars/aurora.png",
      "fav": {
        "love": [
          "F49",
          "F79"
        ],
        "like": [
          "F10",
          "F3",
          "F82",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F12",
          "F16",
          "F69",
          "F87"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "BigWood",
      "name": "大木头",
      "en": "BigWood",
      "group": "韩服2星",
      "aliases": [
        "BigWood"
      ],
      "img": "assets/chars/BigWood.png",
      "fav": {
        "love": [
          "F53",
          "F81"
        ],
        "like": [
          "F30",
          "F25",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F90",
          "F37"
        ],
        "hate": [
          "F14",
          "F22",
          "F80",
          "F85"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Rohne",
      "name": "洛涅",
      "en": "Rohne",
      "group": "韩服2星",
      "aliases": [
        "Rohne"
      ],
      "img": "assets/chars/Rohne.png",
      "fav": {
        "love": [
          "F52",
          "F83"
        ],
        "like": [
          "F24",
          "F2",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F20",
          "F12",
          "F69",
          "F77"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Gabia",
      "name": "加维亚",
      "en": "Gabia",
      "group": "韩服2星",
      "aliases": [
        "Gabia"
      ],
      "img": "assets/chars/Gabia.png",
      "fav": {
        "love": [
          "F43",
          "F74"
        ],
        "like": [
          "F10",
          "F18",
          "F31",
          "F32",
          "F90",
          "F34",
          "F35",
          "F36",
          "F33",
          "F37"
        ],
        "hate": [
          "F3",
          "F23",
          "F71",
          "F82"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Mago",
      "name": "玛戈",
      "en": "Mago",
      "group": "韩服2星",
      "aliases": [
        "Mago"
      ],
      "img": "assets/chars/Mago.png",
      "fav": {
        "love": [
          "F41",
          "F69"
        ],
        "like": [
          "F12",
          "F5",
          "F76",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F14",
          "F8",
          "F80"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Speaki",
      "name": "斯碧琪",
      "en": "Speaki",
      "group": "韩服2星",
      "aliases": [
        "Speaki"
      ],
      "img": "assets/chars/Speaki.png",
      "fav": {
        "love": [
          "F43",
          "F74"
        ],
        "like": [
          "F18",
          "F22",
          "F85",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F6",
          "F17",
          "F78",
          "F88"
        ]
      },
      "source": "wiki",
      "personality": "pure"
    },
    {
      "id": "Lethe",
      "name": "勒忒",
      "en": "Lethe",
      "group": "韩服2星",
      "aliases": [
        "Lethe"
      ],
      "img": "assets/chars/Lethe.png",
      "fav": {
        "love": [
          "F44",
          "F71"
        ],
        "like": [
          "F20",
          "F23",
          "F77",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F25",
          "F16",
          "F81",
          "F87"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Espi",
      "name": "埃斯皮",
      "en": "Espi",
      "group": "韩服2星",
      "aliases": [
        "Espi"
      ],
      "img": "assets/chars/Espi.png",
      "fav": {
        "love": [
          "F60"
        ],
        "like": [
          "F28",
          "F2",
          "F32",
          "F33",
          "F31",
          "F34",
          "F35",
          "F36",
          "F37",
          "F72",
          "F90"
        ],
        "hate": [
          "F15",
          "F4",
          "F70",
          "F73"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "Canta",
      "name": "康塔",
      "en": "Canta",
      "group": "韩服2星",
      "aliases": [
        "Canta"
      ],
      "img": "assets/chars/Canta.png",
      "fav": {
        "love": [],
        "like": [
          "F1",
          "F5",
          "F68",
          "F76",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F10",
          "F20",
          "F77",
          "F79"
        ]
      },
      "source": "wiki",
      "personality": "calm"
    },
    {
      "id": "MaestroMK2",
      "name": "大师2号",
      "en": "MaestroMK2",
      "group": "韩服2星",
      "aliases": [
        "MaestroMK2"
      ],
      "img": "assets/chars/MaestroMK2.png",
      "fav": {
        "love": [
          "F58",
          "F85"
        ],
        "like": [
          "F22",
          "F11",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F7",
          "F19",
          "F89"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Ifrit",
      "name": "伊芙利特",
      "en": "Ifrit",
      "group": "韩服2星",
      "aliases": [
        "Ifrit"
      ],
      "img": "assets/chars/Ifrit.png",
      "fav": {
        "love": [
          "F47",
          "F82",
          "F89"
        ],
        "like": [
          "F3",
          "F23",
          "F71",
          "F78",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F2",
          "F72",
          "F73",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Mayo",
      "name": "玛约",
      "en": "Mayo",
      "group": "韩服2星",
      "aliases": [
        "Mayo"
      ],
      "img": "assets/chars/Mayo.png",
      "fav": {
        "love": [
          "F61"
        ],
        "like": [
          "F30",
          "F11",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F23",
          "F6",
          "F71",
          "F78"
        ]
      },
      "source": "wiki",
      "personality": "frenzy"
    },
    {
      "id": "Beni",
      "name": "班尼",
      "en": "Beni",
      "group": "韩服2星",
      "aliases": [
        "Beni"
      ],
      "img": "assets/chars/Beni.png",
      "fav": {
        "love": [
          "F42",
          "F70"
        ],
        "like": [
          "F15",
          "F26",
          "F86",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F23",
          "F71",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Marie",
      "name": "玛丽",
      "en": "Marie",
      "group": "韩服2星",
      "aliases": [
        "Marie"
      ],
      "img": "assets/chars/Marie.png",
      "fav": {
        "love": [
          "F45",
          "F72"
        ],
        "like": [
          "F28",
          "F3",
          "F82",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F18",
          "F22",
          "F74",
          "F85"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Jubee",
      "name": "茱比",
      "en": "Jubee",
      "group": "韩服2星",
      "aliases": [
        "Jubee"
      ],
      "img": "assets/chars/Jubee.png",
      "fav": {
        "love": [
          "F42",
          "F70"
        ],
        "like": [
          "F15",
          "F29",
          "F75",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F14",
          "F8",
          "F80"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Bana",
      "name": "芭娜",
      "en": "Bana",
      "group": "韩服2星",
      "aliases": [
        "Bana"
      ],
      "img": "assets/chars/Bana.png",
      "fav": {
        "love": [
          "F38",
          "F68"
        ],
        "like": [
          "F28",
          "F1",
          "F72",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F22",
          "F10",
          "F79",
          "F85"
        ]
      },
      "source": "wiki",
      "personality": "lively"
    },
    {
      "id": "Festa",
      "name": "菲斯塔",
      "en": "Festa",
      "group": "韩服2星",
      "aliases": [
        "Festa"
      ],
      "img": "assets/chars/Festa.png",
      "fav": {
        "love": [
          "F51",
          "F77"
        ],
        "like": [
          "F20",
          "F11",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F12",
          "F69",
          "F76"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Levi",
      "name": "莱薇",
      "en": "Levi",
      "group": "韩服2星",
      "aliases": [
        "Levi"
      ],
      "img": "assets/chars/Levi.png",
      "fav": {
        "love": [
          "F39",
          "F73"
        ],
        "like": [
          "F4",
          "F28",
          "F72",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F25",
          "F3",
          "F81",
          "F82"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Silphir",
      "name": "希菲尔",
      "en": "Silphir",
      "group": "韩服2星",
      "aliases": [
        "Silphir"
      ],
      "img": "assets/chars/Silphir.png",
      "fav": {
        "love": [
          "F52",
          "F83"
        ],
        "like": [
          "F24",
          "F19",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F16",
          "F25",
          "F81",
          "F87"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Barie",
      "name": "巴丽叶",
      "en": "Barie",
      "group": "韩服2星",
      "aliases": [
        "Barie"
      ],
      "img": "assets/chars/Barie.png",
      "fav": {
        "love": [
          "F46",
          "F75"
        ],
        "like": [
          "F29",
          "F28",
          "F72",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F23",
          "F9",
          "F71",
          "F84"
        ]
      },
      "source": "wiki",
      "personality": "gloomy"
    },
    {
      "id": "Allet",
      "name": "阿莱特",
      "en": "Allet",
      "group": "韩服1星",
      "aliases": [
        "Allet"
      ],
      "img": "assets/chars/Allet.png",
      "fav": {
        "love": [
          "F12",
          "F69",
          "F73"
        ],
        "like": [
          "F41",
          "F18",
          "F43",
          "F74",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F5",
          "F40",
          "F7",
          "F59",
          "F76",
          "F88"
        ]
      },
      "source": "manual",
      "personality": "pure"
    },
    {
      "id": "Sari",
      "name": "莎里",
      "en": "Sari",
      "group": "韩服1星",
      "aliases": [
        "Sari"
      ],
      "img": "assets/chars/Sari.png",
      "fav": {
        "love": [
          "F54",
          "F86"
        ],
        "like": [
          "F26",
          "F3",
          "F82",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F7",
          "F15",
          "F70",
          "F89"
        ]
      },
      "source": "table",
      "personality": "pure"
    },
    {
      "id": "Cuee",
      "name": "路易",
      "en": "Cuee",
      "group": "韩服1星",
      "aliases": [
        "Cuee"
      ],
      "img": "assets/chars/Cuee.png",
      "fav": {
        "love": [
          "F50",
          "F80"
        ],
        "like": [
          "F14",
          "F1",
          "F38",
          "F68",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F28",
          "F45",
          "F3",
          "F47",
          "F72",
          "F82"
        ]
      },
      "source": "manual",
      "personality": "pure"
    },
    {
      "id": "Patula",
      "name": "帕特拉",
      "en": "Patula",
      "group": "韩服1星",
      "aliases": [
        "Patula"
      ],
      "img": "assets/chars/Patula.png",
      "fav": {
        "love": [
          "F27"
        ],
        "like": [
          "F65",
          "F1",
          "F38",
          "F68",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F12",
          "F41",
          "F5",
          "F40",
          "F69",
          "F76"
        ]
      },
      "source": "manual",
      "personality": "calm"
    },
    {
      "id": "Lazy",
      "name": "雷吉",
      "en": "Lazy",
      "group": "韩服1星",
      "aliases": [
        "Lazy"
      ],
      "img": "assets/chars/Lazy.png",
      "fav": {
        "love": [
          "F40",
          "F76"
        ],
        "like": [
          "F5",
          "F9",
          "F55",
          "F84",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F6",
          "F48",
          "F11",
          "F61",
          "F78"
        ]
      },
      "source": "manual",
      "personality": "calm"
    },
    {
      "id": "Maison",
      "name": "美空",
      "en": "Maison",
      "group": "韩服1星",
      "aliases": [
        "Maison"
      ],
      "img": "assets/chars/Maison.png",
      "fav": {
        "love": [
          "F40",
          "F76"
        ],
        "like": [
          "F5",
          "F7",
          "F59",
          "F87",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F9",
          "F55",
          "F24",
          "F52",
          "F83",
          "F84"
        ]
      },
      "source": "manual",
      "personality": "frenzy"
    },
    {
      "id": "Yumimi",
      "name": "刘美美",
      "en": "Yumimi",
      "group": "韩服1星",
      "aliases": [
        "Yumimi"
      ],
      "img": "assets/chars/Yumimi.png",
      "fav": {
        "love": [
          "F50",
          "F80"
        ],
        "like": [
          "F14",
          "F12",
          "F41",
          "F69",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F22",
          "F58",
          "F9",
          "F55",
          "F84",
          "F85"
        ]
      },
      "source": "manual",
      "personality": "frenzy"
    },
    {
      "id": "Mynx",
      "name": "米雪",
      "en": "Mynx",
      "group": "韩服1星",
      "aliases": [
        "Mynx"
      ],
      "img": "assets/chars/Mynx.png",
      "fav": {
        "love": [
          "F40",
          "F76"
        ],
        "like": [
          "F5",
          "F14",
          "F50",
          "F80",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F22",
          "F58",
          "F28",
          "F45",
          "F72",
          "F85"
        ]
      },
      "source": "manual",
      "personality": "lively"
    },
    {
      "id": "Carren",
      "name": "卡伦",
      "en": "Carren",
      "group": "韩服1星",
      "aliases": [
        "Carren"
      ],
      "img": "assets/chars/Carren.png",
      "fav": {
        "love": [
          "F45",
          "F72"
        ],
        "like": [
          "F28",
          "F1",
          "F38",
          "F68",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F18",
          "F43",
          "F27",
          "F65",
          "F74"
        ]
      },
      "source": "manual",
      "personality": "lively"
    },
    {
      "id": "Taida",
      "name": "泰达",
      "en": "Taida",
      "group": "韩服1星",
      "aliases": [
        "Taida"
      ],
      "img": "assets/chars/Taida.png",
      "fav": {
        "love": [
          "F55",
          "F84"
        ],
        "like": [
          "F9",
          "F24",
          "F52",
          "F83",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F14",
          "F50",
          "F25",
          "F53",
          "F80",
          "F81"
        ]
      },
      "source": "manual",
      "personality": "lively"
    },
    {
      "id": "Veroo",
      "name": "贝鲁",
      "en": "Veroo",
      "group": "韩服1星",
      "aliases": [
        "Veroo"
      ],
      "img": "assets/chars/Veroo.png",
      "fav": {
        "love": [
          "F63"
        ],
        "like": [
          "F19",
          "F4",
          "F39",
          "F73",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F8",
          "F66",
          "F12",
          "F41",
          "F69",
          "F77"
        ]
      },
      "source": "manual",
      "personality": "gloomy"
    },
    {
      "id": "Chopi",
      "name": "乔菲",
      "en": "Chopi",
      "group": "韩服1星",
      "aliases": [
        "Chopi"
      ],
      "img": "assets/chars/Chopi.png",
      "fav": {
        "love": [
          "F66"
        ],
        "like": [
          "F8",
          "F5",
          "F40",
          "F76",
          "F90",
          "F34",
          "F35",
          "F36",
          "F31",
          "F32",
          "F33",
          "F37"
        ],
        "hate": [
          "F19",
          "F63",
          "F13",
          "F62"
        ]
      },
      "source": "manual",
      "personality": "gloomy"
    },
    {
      "id": "Vivi(Duvune)",
      "name": "薇薇（神圣）",
      "en": "Vivi(Duvune)",
      "group": "韩服3星",
      "personality": "resonance",
      "aliases": [
        "Vivi(Duvune)",
        "비비(신성)"
      ],
      "img": "assets/chars/Vivi(Duvune).png",
      "fav": {
        "love": [
          "F55",
          "F84"
        ],
        "like": [
          "F9",
          "F74",
          "F43",
          "F18"
        ],
        "hate": [
          "F5",
          "F40",
          "F76",
          "F51",
          "F77",
          "F20"
        ]
      },
      "source": "manual"
    },
    {
      "id": "Ui(Memory)",
      "name": "雨伊(记忆)",
      "en": "Ui(Memory)",
      "group": "韩服3星",
      "personality": "calm",
      "aliases": [
        "Ui(Memory)",
        "우이(기억)"
      ],
      "img": "assets/chars/Ui(Memory).png",
      "fav": {
        "love": [
          "F87",
          "F56"
        ],
        "like": [
          "F16",
          "F8",
          "F66"
        ],
        "hate": [
          "F84",
          "F55",
          "F9",
          "F57",
          "F88",
          "F17"
        ]
      },
      "source": "manual"
    }
  ],
  "foods": [
    {
      "id": "F1",
      "name": "草莓蛋糕",
      "img": "assets/foods/Icon_Food_1.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F2",
      "name": "巧克力冰淇淋",
      "img": "assets/foods/Icon_Food_2.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F3",
      "name": "奶油布丁",
      "img": "assets/foods/Icon_Food_3.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F4",
      "name": "焦糖爆米花",
      "img": "assets/foods/Icon_Food_4.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F5",
      "name": "饲料罐头",
      "img": "assets/foods/Icon_Food_5.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F6",
      "name": "结绳面包",
      "img": "assets/foods/Icon_Food_6.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F7",
      "name": "米粉",
      "img": "assets/foods/Icon_Food_26.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F8",
      "name": "漫画烤肉",
      "img": "assets/foods/Icon_Food_8.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F9",
      "name": "热冰美式咖啡",
      "img": "assets/foods/Icon_Food_9.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F10",
      "name": "柠檬茶",
      "img": "assets/foods/Icon_Food_10.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F11",
      "name": "神秘的葡萄汁",
      "img": "assets/foods/Icon_Food_11.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F12",
      "name": "太空粮食",
      "img": "assets/foods/Icon_Food_12.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F13",
      "name": "甜瓜芝士",
      "img": "assets/foods/Icon_Food_13.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F14",
      "name": "一口菜包菜",
      "img": "assets/foods/Icon_Food_14.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F15",
      "name": "蜜罐",
      "img": "assets/foods/Icon_Food_15.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F16",
      "name": "海草沙拉",
      "img": "assets/foods/Icon_Food_16.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F17",
      "name": "南瓜汤",
      "img": "assets/foods/Icon_Food_17.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F18",
      "name": "桂皮糖果",
      "img": "assets/foods/Icon_Food_18.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F19",
      "name": "幽灵布丁",
      "img": "assets/foods/Icon_Food_19.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F20",
      "name": "油炸空气条",
      "img": "assets/foods/Icon_Food_20.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F21",
      "name": "宝石蛋挞",
      "img": "assets/foods/Icon_Food_21.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F22",
      "name": "石榴石果实",
      "img": "assets/foods/Icon_Food_22.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F23",
      "name": "龙族糖果",
      "img": "assets/foods/Icon_Food_23.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F24",
      "name": "金糖葫芦",
      "img": "assets/foods/Icon_Food_24.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F25",
      "name": "椰子松叶粥",
      "img": "assets/foods/Icon_Food_25.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F26",
      "name": "蜂蜜蒜香鲢鱼",
      "img": "assets/foods/Icon_Food_7.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F27",
      "name": "薄荷巧克力冰淇淋",
      "img": "assets/foods/Icon_Food_27.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F28",
      "name": "UFC炸萝卜",
      "img": "assets/foods/Icon_Food_28.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F29",
      "name": "棉花糖马卡龙",
      "img": "assets/foods/Icon_Food_29.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F30",
      "name": "一碗米饭",
      "img": "assets/foods/Icon_Food_30.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F31",
      "name": "甜甜维C",
      "img": "assets/foods/Icon_Food_31.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F32",
      "name": "松饼",
      "img": "assets/foods/Icon_Food_32.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F33",
      "name": "酸酸维F",
      "img": "assets/foods/Icon_Food_33.png",
      "aliases": [],
      "upgrade_of": "F31"
    },
    {
      "id": "F34",
      "name": "圣诞树桩蛋糕",
      "img": "assets/foods/Icon_Food_34.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F35",
      "name": "杏仁费列罗",
      "img": "assets/foods/Icon_Food_35.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F36",
      "name": "年糕汤",
      "img": "assets/foods/Icon_Food_36.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F37",
      "name": "艾心堂坨糖果",
      "img": "assets/foods/Icon_Food_37.png",
      "aliases": [],
      "upgrade_of": null
    },
    {
      "id": "F38",
      "name": "哇啊草莓蛋糕",
      "img": "assets/foods/Icon_Food_38.png",
      "aliases": [],
      "upgrade_of": "F1"
    },
    {
      "id": "F39",
      "name": "精飞焦糖爆米花（精灵+网飞）",
      "img": "assets/foods/Icon_Food_39.png",
      "aliases": [],
      "upgrade_of": "F4"
    },
    {
      "id": "F40",
      "name": "高级饲料罐头",
      "img": "assets/foods/Icon_Food_40.png",
      "aliases": [],
      "upgrade_of": "F5"
    },
    {
      "id": "F41",
      "name": "ANSA宇宙粮食",
      "img": "assets/foods/Icon_Food_41.png",
      "aliases": [],
      "upgrade_of": "F12"
    },
    {
      "id": "F42",
      "name": "哼唧蜜罐",
      "img": "assets/foods/Icon_Food_42.png",
      "aliases": [],
      "upgrade_of": "F15"
    },
    {
      "id": "F43",
      "name": "桂皮健康糖果",
      "img": "assets/foods/Icon_Food_43.png",
      "aliases": [],
      "upgrade_of": "F18"
    },
    {
      "id": "F44",
      "name": "龙族细工糖果",
      "img": "assets/foods/Icon_Food_44.png",
      "aliases": [],
      "upgrade_of": "F23"
    },
    {
      "id": "F45",
      "name": "UFC油炸蔬菜",
      "img": "assets/foods/Icon_Food_45.png",
      "aliases": [],
      "upgrade_of": "F28"
    },
    {
      "id": "F46",
      "name": "低糖棉花糖马卡龙",
      "img": "assets/foods/Icon_Food_46.png",
      "aliases": [],
      "upgrade_of": "F29"
    },
    {
      "id": "F47",
      "name": "软冰淇淋布丁",
      "img": "assets/foods/Icon_Food_47.png",
      "aliases": [],
      "upgrade_of": "F3"
    },
    {
      "id": "F48",
      "name": "爱心结绳包",
      "img": "assets/foods/Icon_Food_48.png",
      "aliases": [],
      "upgrade_of": "F6"
    },
    {
      "id": "F49",
      "name": "有机柠檬茶",
      "img": "assets/foods/Icon_Food_49.png",
      "aliases": [],
      "upgrade_of": "F10"
    },
    {
      "id": "F50",
      "name": "两口菜包菜",
      "img": "assets/foods/Icon_Food_50.png",
      "aliases": [],
      "upgrade_of": "F14"
    },
    {
      "id": "F51",
      "name": "油炸氢气条",
      "img": "assets/foods/Icon_Food_51.png",
      "aliases": [],
      "upgrade_of": "F20"
    },
    {
      "id": "F52",
      "name": "白金糖葫芦",
      "img": "assets/foods/Icon_Food_52.png",
      "aliases": [],
      "upgrade_of": "F24"
    },
    {
      "id": "F53",
      "name": "椰子万能绿汁",
      "img": "assets/foods/Icon_Food_53.png",
      "aliases": [],
      "upgrade_of": "F25"
    },
    {
      "id": "F54",
      "name": "皇家蜂蜜蒜香鲢鱼",
      "img": "assets/foods/Icon_Food_54.png",
      "aliases": [],
      "upgrade_of": "F26"
    },
    {
      "id": "F55",
      "name": "热冷冻美式咖啡",
      "img": "assets/foods/Icon_Food_55.png",
      "aliases": [],
      "upgrade_of": "F9"
    },
    {
      "id": "F56",
      "name": "海草波奇",
      "img": "assets/foods/Icon_Food_56.png",
      "aliases": [],
      "upgrade_of": "F16"
    },
    {
      "id": "F57",
      "name": "炖南瓜汤",
      "img": "assets/foods/Icon_Food_57.png",
      "aliases": [],
      "upgrade_of": "F17"
    },
    {
      "id": "F58",
      "name": "石榴石甘露",
      "img": "assets/foods/Icon_Food_58.png",
      "aliases": [],
      "upgrade_of": "F22"
    },
    {
      "id": "F59",
      "name": "927谷米粉",
      "img": "assets/foods/Icon_Food_59.png",
      "aliases": [],
      "upgrade_of": "F7"
    },
    {
      "id": "F60",
      "name": "黑巧克力冰淇淋",
      "img": "assets/foods/Icon_Food_60.png",
      "aliases": [],
      "upgrade_of": "F2"
    },
    {
      "id": "F61",
      "name": "一级神秘的葡萄汁",
      "img": "assets/foods/Icon_Food_62.png",
      "aliases": [],
      "upgrade_of": "F11"
    },
    {
      "id": "F62",
      "name": "马斯克甜瓜芝士",
      "img": "assets/foods/Icon_Food_63.png",
      "aliases": [],
      "upgrade_of": "F13"
    },
    {
      "id": "F63",
      "name": "恶灵布丁",
      "img": "assets/foods/Icon_Food_64.png",
      "aliases": [],
      "upgrade_of": "F19"
    },
    {
      "id": "F64",
      "name": "宝物蛋挞",
      "img": "assets/foods/Icon_Food_65.png",
      "aliases": [],
      "upgrade_of": "F21"
    },
    {
      "id": "F65",
      "name": "三倍薄荷巧克力冰淇淋",
      "img": "assets/foods/Icon_Food_66.png",
      "aliases": [],
      "upgrade_of": "F27"
    },
    {
      "id": "F66",
      "name": "海盗漫画烤肉",
      "img": "assets/foods/Icon_Food_61.png",
      "aliases": [],
      "upgrade_of": "F8"
    },
    {
      "id": "F67",
      "name": "一碗糯米饭",
      "img": "assets/foods/Icon_Food_67.png",
      "aliases": [],
      "upgrade_of": "F30"
    },
    {
      "id": "X133373",
      "name": "烤肉",
      "img": "assets/foods/133373.png",
      "aliases": [],
      "upgrade_of": null,
      "unverified": true
    },
    {
      "id": "F68",
      "name": "艾心堂草莓蛋糕",
      "img": "assets/foods/F68.png",
      "aliases": [],
      "upgrade_of": "F38"
    },
    {
      "id": "F69",
      "name": "宇宙次元食粮",
      "img": "assets/foods/F69.png",
      "aliases": [],
      "upgrade_of": "F41"
    },
    {
      "id": "F70",
      "name": "哼唧蜂蜜罐",
      "img": "assets/foods/F70.png",
      "aliases": [],
      "upgrade_of": "F42"
    },
    {
      "id": "F71",
      "name": "龙敢糖果",
      "img": "assets/foods/F71.png",
      "aliases": [],
      "upgrade_of": "F44"
    },
    {
      "id": "F72",
      "name": "UFC全炸福套餐",
      "img": "assets/foods/F72.png",
      "aliases": [],
      "upgrade_of": "F45"
    },
    {
      "id": "F73",
      "name": "啪啪！焦糖爆米花",
      "img": "assets/foods/F73.png",
      "aliases": [],
      "upgrade_of": "F39"
    },
    {
      "id": "F74",
      "name": "红参味健康糖果",
      "img": "assets/foods/F74.png",
      "aliases": [],
      "upgrade_of": "F43"
    },
    {
      "id": "F75",
      "name": "胖嘟嘟棉花糖马卡龙",
      "img": "assets/foods/F75.png",
      "aliases": [],
      "upgrade_of": "F46"
    },
    {
      "id": "F76",
      "name": "VIP罐头饲料",
      "img": "assets/foods/F76.png",
      "aliases": [],
      "upgrade_of": "F40"
    },
    {
      "id": "F77",
      "name": "油炸氮气",
      "img": "assets/foods/F77.png",
      "aliases": [],
      "upgrade_of": "F51"
    },
    {
      "id": "F78",
      "name": "三层麻花面包",
      "img": "assets/foods/F78.png",
      "aliases": [],
      "upgrade_of": "F48"
    },
    {
      "id": "F79",
      "name": "苏打气泡柠檬茶",
      "img": "assets/foods/F79.png",
      "aliases": [],
      "upgrade_of": "F49"
    },
    {
      "id": "F80",
      "name": "三口菜包菜",
      "img": "assets/foods/F80.png",
      "aliases": [],
      "upgrade_of": "F50"
    },
    {
      "id": "F81",
      "name": "鲜嫩椰果绿汁",
      "img": "assets/foods/F81.png",
      "aliases": [],
      "upgrade_of": "F53"
    },
    {
      "id": "F82",
      "name": "咸口奶油焦糖布蕾",
      "img": "assets/foods/F82.png",
      "aliases": [],
      "upgrade_of": "F47"
    },
    {
      "id": "F83",
      "name": "宝石糖葫芦",
      "img": "assets/foods/F83.png",
      "aliases": [],
      "upgrade_of": "F52"
    },
    {
      "id": "F84",
      "name": "好烫好冷美式咖啡",
      "img": "assets/foods/F84.png",
      "aliases": [],
      "upgrade_of": "F55"
    },
    {
      "id": "F85",
      "name": "石榴石刨冰",
      "img": "assets/foods/F85.png",
      "aliases": [],
      "upgrade_of": "F58"
    },
    {
      "id": "F86",
      "name": "特制蜂蜜大蒜三文鱼",
      "img": "assets/foods/F86.png",
      "aliases": [],
      "upgrade_of": "F54"
    },
    {
      "id": "F87",
      "name": "海草便当",
      "img": "assets/foods/F87.png",
      "aliases": [],
      "upgrade_of": "F16"
    },
    {
      "id": "F88",
      "name": "南瓜粥",
      "img": "assets/foods/F88.png",
      "aliases": [],
      "upgrade_of": "F57"
    },
    {
      "id": "F89",
      "name": "冰块充满五谷粉汁",
      "img": "assets/foods/F89.png",
      "aliases": [],
      "upgrade_of": "F59"
    },
    {
      "id": "F90",
      "name": "维生素K",
      "img": "assets/foods/Icon_Food_90.png",
      "aliases": [
        "VitaminK"
      ],
      "upgrade_of": "F33",
      "source": "manual"
    }
  ],
  "personalities": [
    {
      "id": "resonance",
      "name": "共鸣",
      "icon": "assets/personality/resonance.png"
    },
    {
      "id": "pure",
      "name": "纯粹",
      "icon": "assets/personality/pure.png"
    },
    {
      "id": "calm",
      "name": "冷静",
      "icon": "assets/personality/calm.png"
    },
    {
      "id": "frenzy",
      "name": "狂热",
      "icon": "assets/personality/frenzy.png"
    },
    {
      "id": "lively",
      "name": "活泼",
      "icon": "assets/personality/lively.png"
    },
    {
      "id": "gloomy",
      "name": "忧郁",
      "icon": "assets/personality/gloomy.png"
    }
  ]
};
